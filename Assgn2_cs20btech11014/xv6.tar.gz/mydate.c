#include "types.h"
#include "user.h"
#include "date.h"


int main(int argc, char *argv[])
{

	struct rtcdate r;
	
	if (mydate(&r)) {
		printf(2, "date failed\n");
		exit();
	}
	
	
	exit();
}
